
#ifndef MOVEPICK_H_INCLUDED
#define MOVEPICK_H_INCLUDED

#include <algorithm> // For std::max
#include <cstring>   // For std::memset

#include "movegen.h"
#include "position.h"
#include "search.h"
#include "types.h"


/// The Stats struct stores moves statistics. According to the template parameter
/// the class can store History, Gains and Countermoves. History records how often
/// different moves have been successful or unsuccessful during the current search
/// and is used for reduction and move ordering decisions. Gains records the move's
/// best evaluation gain from one ply to the next and is used for pruning decisions.
/// Countermoves store the move that refute a previous one. Entries are stored
/// using only the moving piece and destination square, hence two moves with
/// different origin but same destination and piece will be considered identical.
template<bool Gain, typename T>
struct Stats {

  static const Value Max = Value(250);

  const T* operator[](Piece pc) const { return table[pc]; }
  void clear() { std::memset(table, 0, sizeof(table)); }

  void update(Piece pc, Square to, Move m) {

    if (m == table[pc][to].first)
        return;

    table[pc][to].second = table[pc][to].first;
    table[pc][to].first = m;
  }

  void update(Piece pc, Square to, Value v) {

    if (Gain)
        table[pc][to] = std::max(v, table[pc][to] - 1);

    else if (abs(table[pc][to] + v) < Max)
        table[pc][to] +=  v;
  }

private:
  T table[PIECE_NB][SQUARE_NB];
};

typedef Stats< true, Value> GainsStats;
typedef Stats<false, Value> HistoryStats;
typedef Stats<false, std::pair<Move, Move> > MovesStats;


/// MovePicker class is used to pick one pseudo legal move at a time from the
/// current position. The most important method is next_move(), which returns a
/// new pseudo legal move each time it is called, until there are no moves left,
/// when MOVE_NONE is returned. In order to improve the efficiency of the alpha
/// beta algorithm, MovePicker attempts to return the moves which are most likely
/// to get a cut-off first.

class MovePicker {

  MovePicker& operator=(const MovePicker&); // Silence a warning under MSVC

public:
  MovePicker(const Position&, Move, Depth, const HistoryStats&, Square);
  MovePicker(const Position&, Move, const HistoryStats&, PieceType);
  MovePicker(const Position&, Move, Depth, const HistoryStats&, Move*, Move*, Search::Stack*);

  template<bool SpNode> Move next_move();

private:
  template<GenType> void score();
  void generate_next_stage();

  const Position& pos;
  const HistoryStats& history;
  Search::Stack* ss;
  Move* countermoves;
  Move* followupmoves;
  Depth depth;
  Move ttMove;
  ExtMove killers[6];
  Square recaptureSquare;
  Value captureThreshold;
  int stage;
  ExtMove *cur, *end, *endQuiets, *endBadCaptures;
  ExtMove moves[MAX_MOVES];
};

#endif // #ifndef MOVEPICK_H_INCLUDED
