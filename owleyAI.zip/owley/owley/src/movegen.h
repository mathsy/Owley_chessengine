
#ifndef MOVEGEN_H_INCLUDED
#define MOVEGEN_H_INCLUDED

#include "types.h"

class Position;

enum GenType {
  CAPTURES,
  QUIETS,
  QUIET_CHECKS,
  EVASIONS,
  NON_EVASIONS,
  LEGAL
};

struct ExtMove {
  Move move;
  Value value;
};

inline bool operator<(const ExtMove& f, const ExtMove& s) {
  return f.value < s.value;
}

template<GenType>
ExtMove* generate(const Position& pos, ExtMove* moveList);

/// The MoveList struct is a simple wrapper around generate(). It sometimes comes
/// in handy to use this class instead of the low level generate() function.
template<GenType T>
struct MoveList {

  explicit MoveList(const Position& pos) : cur(moveList), last(generate<T>(pos, moveList)) { last->move = MOVE_NONE; }
  void operator++() { ++cur; }
  Move operator*() const { return cur->move; }
  size_t size() const { return last - moveList; }
  bool contains(Move m) const {
    for (const ExtMove* it(moveList); it != last; ++it) if (it->move == m) return true;
    return false;
  }

private:
  ExtMove moveList[MAX_MOVES];
  ExtMove *cur, *last;
};

#endif // #ifndef MOVEGEN_H_INCLUDED
