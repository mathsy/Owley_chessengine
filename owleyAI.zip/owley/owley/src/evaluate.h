
#ifndef EVALUATE_H_INCLUDED
#define EVALUATE_H_INCLUDED

#include <string>

#include "types.h"

class Position;

namespace Eval {

const Value Tempo = Value(17); // Must be visible to search

void init();
Value evaluate(const Position& pos);
std::string trace(const Position& pos);

}

#endif // #ifndef EVALUATE_H_INCLUDED
