#ifndef TIMEMAN_H_INCLUDED
#define TIMEMAN_H_INCLUDED

/// The TimeManager class computes the optimal time to think depending on the
/// maximum available time, the game move number and other parameters.

class TimeManager {
public:
  void init(const Search::LimitsType& limits, Color us, int ply);
  void pv_instability(double bestMoveChanges) { unstablePvFactor = 1 + bestMoveChanges; }
  int available_time() const { return int(optimumSearchTime * unstablePvFactor * 0.71); }
  int maximum_time() const { return maximumSearchTime; }

private:
  int optimumSearchTime;
  int maximumSearchTime;
  double unstablePvFactor;
};

#endif // #ifndef TIMEMAN_H_INCLUDED
