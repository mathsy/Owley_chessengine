This is a chess engine which uses UCI.

The Owley chess engine is based on Stockfish 6:
Some script were kept, but there were made some changes like evaluaton, the timeman.cpp and evaluation and
so on.

You can use - as at Stockfish - syzygy tablebases.